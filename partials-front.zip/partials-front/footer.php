   <!--social section starts here -->
   <section class = "social">
    <div class= "container text-center"> 
<ul> 
    <li> 
         <a href="#"><img src="https://img.icons8.com/color/48/null/facebook-new.png"/></a>
         </li>
         <li>
         <a href="#"><img src="https://img.icons8.com/color/48/null/instagram-new--v1.png"/></a>
         </li>
         <li>
           <a href="#" ><img src="https://img.icons8.com/fluency/48/null/apple-mail.png"/></a>
        </li>
</ul>
</div>
</section>
    <!--social section ends here -->
    <!--footer section starts here -->
<section class = "footer">
<div class= "container text-center"> 
<p>
    All Rights Reserved. Designed By Zalika and Maia.
</p>
</div>
</section>
    <!--footer section ends here -->