<?php include ('config/constants.php')?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- important to make website responsive-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Website</title>
    <!-- linking css file: -->
    <link rel = "stylesheet" href="CSS/style.css">

</head>
<body>
    <!--Nav bar section starts here -->
<section class = "navbar">
 <div class= "container"> 
<div class ="logo">
 <img src = "Images/logo.jpg" alt="Restaurant Logo" class = "img-responsive"> 
</div>
<div class ="menu text-right">
 <ul> 
    <li> 
        <a href ="<?php echo SITEURL;?>">Home</a>
    </li>
    <li> 
        <a href ="<?php echo SITEURL;?>about.php">About</a>
    </li>
    <li> 
        <a href ="<?php echo SITEURL;?>foods.php">Foods</a>
    </li>
    <li> 
        <a href ="<?php echo SITEURL;?>contact.php">Contact</a>
    </li>
 </ul>
</div>
<div class ="clearfix"></div>
</div>
</div>
</section>
    <!--Nav bar section ends here -->