    <!-- Footer starts here-->
    <div class="footer">
        <div class ="wrapper">
            <p class ="text-center">2023 All Rights Reserved, Restaurant </p>

        </div>
        </div>
        <!-- Footer ends here-->


    </body>
    
</html>