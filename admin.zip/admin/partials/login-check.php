<?php
if(!isset($_SESSION['user'])){ //if user session is not set
//redirect to login page 
$_SESSION['no-login-message']="<div class = 'error text-'>Please login to access admin panel.</div>";
header('location'.SITEURL.'admin/login.php');
}
?>
