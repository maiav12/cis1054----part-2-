
<?php include('../config/constants.php'); 
include('partials/login-check.php');?>
<html>
    <head>
         <title> Restaurant Website Home page </title>
         <link rel="stylesheet" href="../CSS/admin.css">
    </head>
    <body>
        <!-- Menu Section starts here-->
        <div class="menu text-center">
            <div class = "wrapper">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="manage-admin.php">Admin</a></li>
                <li><a href="manage-category.php">Category</a></li>
                <li><a href="manage-food.php">Food</a></li>
            </ul>
            </div>
        </div>
<?php
// get admin id 
$id=$_GET['id']; 

$sql= "DELETE FROM tbl_admin WHERE id=$id";

$res= mysqli_query($conn, $sql);

if($res==true)
{
  $_SESSION['delete']= "<div class='success'>Admin Deleted Successfully. </div>";
  header('location:'.SITEURL. 'admin/manage-admin.php');
}
else
{ 
    $_SESSION['delete']= "<div class='error'>Failed to Delete Admin. Try Again Later. </div>";
    header('location:'.SITEURL. 'admin/manage-admin.php');
}


// redirect to manage admin page  (success/error)

?>
