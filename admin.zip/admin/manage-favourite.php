<?php include('partials/menu.php'); ?>
        <!-- Menu Content starts here-->
        <div class="main-content">
         <div class ="wrapper">
           
         <h1>Manage Favourite</h1>

         
         <br /><br /><br />

         <table class="tbl-full">
            <tr> 
                <th>S.N.</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Actions</th>
            </tr>
            
            <tr>
                <td>1.</td>
                <td>Maia Vella/td>
                <td>maiavella</td>
                <td>
                    <a href="#"class="btn-secondary">Update Admin</a>
                    <a href="#"class="btn-danger">Delete Admin</a>
                </td>
            </tr>

            <tr>
                <td>2.</td>
                <td>Zalika Penza/td>
                <td>zalikapenza</td>
                <td>
                   <a href="#"class="btn-secondary">Update Admin</a>
                    <a href="#"class="btn-danger">Delete Admin</a>
                </td>
            </tr>

            
         <table>

            </div>
        </div>
        <!-- Menu Content ends here-->

   <?php include('partials/footer.php');?>
   