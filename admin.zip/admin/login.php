<?php include ('../config/constants.php'); ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Login - Restaurant System</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../CSS/admin.css">
    </head>
    <body>
       
<div class ="login">
        <h1 class="text-center">LOGIN</h1>

        <?php
        if(isset($_SESSION['login'])){

            echo $_SESSION['login']; 
            unset($_SESSION['login']);
        
        }
        if(isset($_SESSION['no-login-message'])){
            echo $_SESSION['no-login-message'];
            unset( $_SESSION['no-login-message']);
        }
        ?>
        <br><br>
        <!-- LOGIN form starts here -->
        <form action="" method="POST" class ="text-center">
            Username: <br>
            <input type ="text" name="Username" placeholder="Enter username"><br><br>
            
            Password:<br>
            <input type ="password" name="Password" placeholder="Enter password"><br><br>

            <input type ="submit" name="submit" value="Login" class="btn-primary">
            <br><br>

        </form>
        <!-- LOGIN form ends here -->

    <p class="text-center"> Created by Maia and Zalika</p>
</div>
    </body>
</html>
<?php
    if(isset($_POST['submit'])){
        $username=$_POST['Username'];
        $password=md5($_POST['Password']);
        $sql = "SELECT * FROM tbl_admin WHERE Username='$username' AND Password='$password'";
         $res=mysqli_query($conn, $sql);
        //count rows to check whether the user exists or not 
        $count =mysqli_num_rows($res);
        if($count==1){
           //user available
           $_SESSION['login'] = "<div class='success'>Login Successful.</div>";
            $_SESSION['user'] = $username;
            header('location:'.SITEURL.'admin/');

        }
        else{
            //user not available
            $_SESSION['login']="<div class ='error text-center'>Username or password did not match.</div>";
           header('location:' .SITEURL.'admin/login.php');
        }
    }
?>
